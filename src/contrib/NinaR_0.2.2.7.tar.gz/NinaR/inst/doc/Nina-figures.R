## ---- echo=F, message=F-------------------------------------------------------
require(NinaR)
require(grid)
require(ggplot2)
knitr::opts_chunk$set(
  dev = 'svg'
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----palette------------------------------------------------------------------
palette(ninaPalette())
palette()

## ----pallettefunction, fig.width=7, fig.height=5------------------------------
require(NinaR)
plot(10:1, cex=2, pch=16, col=ninaLogoPalette())

## ----addAlpha, fig.width=7, fig.height=5--------------------------------------
set.seed(12345)
barplot(runif(5), col=addAlpha(ninaPalette(), 0.4))

## ----addlogo, fig.width=7, fig.height=5---------------------------------------
plot((1:10)^2, 1:10, col=ninaPalette(), cex=4, pch=16, las=1)
addLogo()

## ----addbackgroundlogo, fig.width=7, fig.height=5-----------------------------
plot((1:10)^2, 1:10, col=ninaPalette(), cex=4, pch=16, las=1, type="n")
addLogo(x = 0.5, y = 0.5, size = 1)
grid.rect(gp = gpar(fill = rgb(1, 1, 1, .6)))
points((1:10)^2, 1:10, col=ninaPalette(), cex=4, pch=16)

## ----scale_fill_nina_continous, fig.width=7, fig.height=5---------------------
g <- ggplot(faithfuld, aes(waiting, eruptions))
g + geom_raster(aes(fill = density)) +
  scale_fill_nina(discrete = F)

## ----scale_fill_nina_discrete, fig.width=7, fig.height=5----------------------
g <- ggplot(mpg, aes(class))
g + geom_bar(aes(fill = drv)) +
   scale_fill_nina(palette = "logo")

## ----scale_color_nina_discrete, fig.width=7, fig.height=5---------------------
g <- ggplot(mpg, aes(cyl, hwy)) 
g + geom_point(aes(colour = drv)) +
   scale_color_nina(discrete = T)

## ----scale_color_nina_continuous, fig.width=7, fig.height=5-------------------
g <- ggplot(mpg, aes(cty, hwy)) 
g + geom_point(aes(colour = cyl)) +
   scale_color_nina(discrete = F)

## ----add_logo, fig.width=7, fig.height=5--------------------------------------
g <- ggplot(mpg, aes(cty, hwy))  +
  geom_point(aes(colour = cyl)) +
   scale_color_nina(discrete = F) +
  add_logo(xmin = 25,
           xmax = 30,
           stroke_scale = 0.3)

g


